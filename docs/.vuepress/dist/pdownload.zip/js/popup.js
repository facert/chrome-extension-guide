﻿chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
	url = tabs[0].url
	title = tabs[0].title
	console.log(url)
	console.log(title)
	if (url != undefined && url.match(/https:\/\/.*?\.pornhub\.com\/view_video\.php\?viewkey=.*/)) {
		html = '<h5>' + title +'</h5>'
		html += '<a target="_blank" href="https://mydownload.fun/download?url='+ url +'"><span class="btn"><img class="icon" src="../css/download.svg"/>Download</span></a>'	
		$("#video_info").append(html)

	}
})